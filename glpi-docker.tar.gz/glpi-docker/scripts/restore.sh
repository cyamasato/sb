#!/usr/bin/env bash
# Restaura um backup. Uso: scripts/restore.sh <glpi-db-*.sql.gz> <glpi-files-*.tar.gz>
# Rodar como root. SOBRESCREVE banco e arquivos atuais.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
DB_FILE=$1; FILES_FILE=$2

read -rp "Isto apaga os dados atuais do GLPI. Digite RESTAURAR: " c
[ "$c" = "RESTAURAR" ] || exit 1

docker compose stop glpi

# Arquivos
rm -rf "$DATA_DIR/glpi/config/"* "$DATA_DIR/glpi/files/"* "$DATA_DIR/glpi/marketplace/"* "$DATA_DIR/glpi/plugins/"*
tar xzf "$FILES_FILE" -C "$DATA_DIR"
chown -R 33:33 "$DATA_DIR/glpi"
chmod 2775 "$DATA_DIR/glpi/plugins"

# Banco
docker compose exec -T -e MYSQL_PWD="$DB_ROOT_PASSWORD" db \
  mariadb -u root -e "DROP DATABASE IF EXISTS \`$GLPI_DB_NAME\`; CREATE DATABASE \`$GLPI_DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
gzip -cd "$DB_FILE" | docker compose exec -T -e MYSQL_PWD="$DB_ROOT_PASSWORD" db \
  mariadb -u root "$GLPI_DB_NAME"

docker compose start glpi
echo "OK — restaurado. Confira login e Configurar > Geral > Sistema."
