#!/usr/bin/env bash
# Prepara o host antes do 1º "docker compose up". Rodar como root.
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f .env ] || { echo "ERRO: crie o .env a partir do .env.example"; exit 1; }
grep -q '=TROCAR' .env && { echo "ERRO: troque as senhas TROCAR no .env"; exit 1; }
set -a; source .env; set +a
[[ "$DATA_DIR" = /* ]] || { echo "ERRO: DATA_DIR precisa ser caminho absoluto"; exit 1; }

mkdir -p \
  "$DATA_DIR/mariadb" \
  "$DATA_DIR/glpi/config" "$DATA_DIR/glpi/files" \
  "$DATA_DIR/glpi/marketplace" "$DATA_DIR/glpi/plugins" "$DATA_DIR/glpi/logs" \
  "$DATA_DIR/traefik/letsencrypt" "$DATA_DIR/traefik/logs" \
  "$DATA_DIR/backups"

chown -R 999:999 "$DATA_DIR/mariadb"      # usuário mysql da imagem mariadb
chown -R 33:33   "$DATA_DIR/glpi"         # www-data da imagem glpi
# plugins: grupo www-data com escrita + setgid, para o usuário de deploy
# (adicione-o ao grupo: usermod -aG www-data <usuario>) publicar sem sudo
chmod 2775 "$DATA_DIR/glpi/plugins"
touch "$DATA_DIR/traefik/letsencrypt/acme.json"
chmod 600 "$DATA_DIR/traefik/letsencrypt/acme.json"
chmod 700 "$DATA_DIR/backups" "$DATA_DIR/glpi/config"
chmod 600 .env

echo "OK — estrutura criada em $DATA_DIR"
find "$DATA_DIR" -maxdepth 2 -type d | sort
