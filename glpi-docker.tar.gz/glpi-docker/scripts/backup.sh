#!/usr/bin/env bash
# Backup do GLPI: dump do banco + config/files/marketplace. Rodar como root.
# Agendar no cron do host (ex.: 0 */6 * * *).
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a

DEST="$DATA_DIR/backups"
KEEP_DAYS=7
STAMP=$(date +%Y%m%d-%H%M)

# 1) Banco — consistente, sem parar o serviço
DB_FILE="$DEST/glpi-db-$STAMP.sql.gz"
docker compose exec -T -e MYSQL_PWD="$DB_ROOT_PASSWORD" db \
  mariadb-dump -u root --single-transaction --routines --triggers --events "$GLPI_DB_NAME" \
  | gzip > "$DB_FILE"
[ "$(gzip -cd "$DB_FILE" | head -c 100 | wc -c)" -gt 0 ] || { echo "ERRO: dump vazio" >&2; exit 1; }

# 2) Arquivos — config (glpicrypt.key!), anexos, marketplace e plugins customizados
FILES_FILE="$DEST/glpi-files-$STAMP.tar.gz"
tar czf "$FILES_FILE" -C "$DATA_DIR" glpi/config glpi/files glpi/marketplace glpi/plugins

# 3) Retenção local
find "$DEST" -name 'glpi-*' -mtime +"$KEEP_DAYS" -delete

# 4) Cópia para fora da VM — DEFINIR DESTINO (rsync/rclone)
# rsync -a "$DEST/" backup@servidor:/backups/glpi/

echo "OK: $DB_FILE $FILES_FILE"
