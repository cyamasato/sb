# GLPI 11 — Docker + Traefik (produção)

## Estrutura

```
glpi-docker/                  ← projeto (versionar no Git, exceto .env)
├── docker-compose.yml
├── .env.example              → copiar para .env
├── traefik/
│   ├── dynamic/middlewares.yml   headers de segurança + TLS mínimo 1.2
│   ├── dynamic/tls.yml.example   só se usar certificado da CA interna
│   └── certs/                    certificado interno (se aplicável)
├── php/glpi.ini              limites PHP + cookies seguros
├── mariadb/glpi.cnf          tuning do MariaDB
├── scripts/
│   ├── init.sh               cria diretórios de dados e permissões
│   ├── backup.sh             dump do banco + arquivos
│   └── restore.sh            restauração
└── host/
    ├── install-docker.sh     instala Docker Engine + Compose (Ubuntu)
    ├── logrotate-glpi        → /etc/logrotate.d/glpi
    └── crontab-glpi          → /etc/cron.d/glpi

/srv/glpi/                    ← DATA_DIR (dados, fora do Git)
├── mariadb/
├── glpi/{config,files,marketplace,plugins,logs}
├── traefik/{letsencrypt,logs}
└── backups/
```

## Volumes

| Volume Docker | Caminho no host | Montado em | Conteúdo | Dono | Backup |
|---|---|---|---|---|---|
| `glpi_mariadb_data` | `$DATA_DIR/mariadb` | db:`/var/lib/mysql` | Banco inteiro | 999 | via **dump** (nunca cópia a quente) |
| `glpi_config` | `$DATA_DIR/glpi/config` | glpi:`/var/glpi/config` | `config_db.php`, **`glpicrypt.key`** | 33 | sim — crítico |
| `glpi_files` | `$DATA_DIR/glpi/files` | glpi:`/var/glpi/files` | Anexos, documentos, cache, sessões | 33 | sim |
| `glpi_marketplace` | `$DATA_DIR/glpi/marketplace` | glpi:`/var/glpi/marketplace` | Plugins do Marketplace | 33 | sim |
| `glpi_plugins` | `$DATA_DIR/glpi/plugins` | glpi:`/var/www/glpi/plugins` | Plugins customizados (código próprio) | 33, grupo com escrita (2775) | sim — mas a fonte da verdade é o Git |
| `glpi_logs` | `$DATA_DIR/glpi/logs` | glpi:`/var/glpi/logs` | Logs da aplicação | 33 | não (logrotate) |
| `glpi_traefik_letsencrypt` | `$DATA_DIR/traefik/letsencrypt` | traefik:`/letsencrypt` | `acme.json` (600) | root | opcional (é reemitido) |
| `glpi_traefik_logs` | `$DATA_DIR/traefik/logs` | traefik:`/logs` | `access.log` — auditoria de acesso | root | conforme política |

Sem a `glpicrypt.key`, as senhas salvas no banco (AD, SMTP, coletores de e-mail) ficam ilegíveis após um restore.

Os volumes são *bind* nomeados: se mudar `DATA_DIR` depois do primeiro start, é preciso `docker compose down` + `docker volume rm` dos volumes antes de subir de novo.

## Instalação

```bash
sudo host/install-docker.sh <usuario_deploy>   # só na primeira vez; logout/login depois
cp .env.example .env && nano .env
sudo scripts/init.sh
docker compose up -d
docker compose logs -f glpi          # aguarde o fim da instalação automática
sudo cp host/logrotate-glpi /etc/logrotate.d/glpi
sudo cp host/crontab-glpi   /etc/cron.d/glpi
```

Depois:
1. Login `glpi/glpi` → trocar senha; desativar `tech`, `normal`, `post-only`.
2. Configurar > Geral → URL da aplicação `https://<GLPI_DOMAIN>`.
3. Fuso horário:
   ```bash
   source .env
   docker compose exec db mariadb -u root -p -e "GRANT SELECT ON mysql.time_zone_name TO '$GLPI_DB_USER'@'%'; FLUSH PRIVILEGES;"
   docker compose exec glpi bin/console database:enable_timezones
   ```
4. Validar em Administração > Logs se o IP registrado é o do usuário (e não o do Traefik).

## Plugins customizados

Marketplace e plugins customizados ficam em volumes separados: o GLPI procura plugins nos dois diretórios, então **não use o mesmo nome de pasta nos dois**.

Fluxo recomendado: desenvolver e testar em homologação → versionar no Git → publicar em produção.

```bash
# publicar (a pasta precisa ter o nome exato do plugin)
rsync -a --delete meuplugin/ /srv/glpi/glpi/plugins/meuplugin/
docker compose exec glpi bin/console plugin:install --username=glpi meuplugin
docker compose exec glpi bin/console plugin:activate meuplugin
```

Para atualizar um plugin já instalado: publicar a nova versão e usar Configurar > Plugins (ou `plugin:install` de novo) para aplicar migrações.

## Atualização de versão

```bash
sudo scripts/backup.sh
nano .env                            # nova GLPI_VERSION
docker compose pull glpi && docker compose up -d glpi
docker compose exec glpi bin/console db:update
```

## Restore

```bash
sudo scripts/restore.sh /srv/glpi/backups/glpi-db-AAAAMMDD-HHMM.sql.gz \
                        /srv/glpi/backups/glpi-files-AAAAMMDD-HHMM.tar.gz
```

Teste o restore numa VM separada antes de precisar dele de verdade.
